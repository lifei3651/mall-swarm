import{s as e}from"./request-DXoV5D55.js";function o(t){return e({url:`/distribution/account/agent/${t}`,method:"get"})}export{o as g};
